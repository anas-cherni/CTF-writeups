SECRET = bytes("secret", "utf-8")
